public class Incidencia {

    private int id;
    private String descripcion;
    private String fecha;
    private int fkUsuario;
    private int fkEstado;

    public Incidencia() {}

    public Incidencia(String descripcion, int fkUsuario, int fkEstado) {
        this.descripcion = descripcion;
        this.fkUsuario = fkUsuario;
        this.fkEstado = fkEstado;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public int getFkUsuario() { return fkUsuario; }
    public void setFkUsuario(int fkUsuario) { this.fkUsuario = fkUsuario; }

    public int getFkEstado() { return fkEstado; }
    public void setFkEstado(int fkEstado) { this.fkEstado = fkEstado; }
}