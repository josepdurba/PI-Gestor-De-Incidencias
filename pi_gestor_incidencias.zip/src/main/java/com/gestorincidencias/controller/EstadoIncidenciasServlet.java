package com.gestorincidencias.controller;

import com.gestorincidencias.model.Incidencia;
import com.gestorincidencias.util.Conexion;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/estado-incidencias")
public class EstadoIncidenciasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Incidencia> incidencias = new ArrayList<>();

        String sql =
                "SELECT i.descripcion, i.fecha, e.estado " +
                        "FROM incidencias i " +
                        "JOIN estados e ON i.fk_estado = e.id";

        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                Incidencia incidencia = new Incidencia();

                incidencia.setDescripcion(rs.getString("descripcion"));
                incidencia.setFecha(rs.getString("fecha"));
                incidencia.setEstado(rs.getString("estado"));

                incidencias.add(incidencia);
            }

        } catch (SQLException | ClassNotFoundException e) {
            throw new ServletException("Error al obtener incidencias", e);
        }

        request.setAttribute("incidencias", incidencias);

        request.getRequestDispatcher("estado_incidencias.jsp")
                .forward(request, response);
    }
}