package com.gestorincidencias.controller;

import com.gestorincidencias.dao.UsuarioDAO;
import com.gestorincidencias.model.Usuario;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String nombre = request.getParameter("nombre");
        String password = request.getParameter("password");

        UsuarioDAO dao = new UsuarioDAO();

        Usuario u = dao.login(nombre, password);

        if (u != null) {

            HttpSession session = request.getSession();

            session.setAttribute("usuario", u);

            response.sendRedirect("incidencias.html");

        } else {

            response.sendRedirect("login.html?error=1");
        }
    }
}