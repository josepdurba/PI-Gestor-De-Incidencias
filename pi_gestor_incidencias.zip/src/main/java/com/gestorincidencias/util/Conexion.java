package com.gestorincidencias.util;

import java.sql.*;

public class Conexion {
    public static Connection conectar() throws SQLException, ClassNotFoundException {
        String url = "jdbc:mysql://localhost:3306/pi_gestor_incidencias";
        String user = "root";
        String password = ""; // Recuerda dejarlo vacío si usas XAMPP por defecto

        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url, user, password);
    }
}
