package com.gestorincidencias.dao;

import com.gestorincidencias.model.Incidencia;
import com.gestorincidencias.util.Conexion;

import java.sql.*;

public class IncidenciaDAO {

    // CREATE
    public void insertar(Incidencia i) {

        String sql = "INSERT INTO incidencias " +
                "(descripcion, observaciones, fk_usuario, fk_estado, fecha) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, i.getDescripcion());
            ps.setString(2, i.getObservaciones());
            ps.setInt(3, i.getFkUsuario());
            ps.setInt(4, i.getFkEstado());
            ps.setString(5, i.getFecha());

            ps.executeUpdate();

            System.out.println("Incidencia creada");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // READ
    public void listar() {

        String sql =
                "SELECT i.id, i.descripcion, u.nombre, e.estado " +
                        "FROM incidencias i " +
                        "JOIN usuarios u ON i.fk_usuario = u.id " +
                        "JOIN estados e ON i.fk_estado = e.id";

        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                System.out.println(
                        rs.getInt("id") + " - " +
                                rs.getString("descripcion") + " - " +
                                rs.getString("nombre") + " - " +
                                rs.getString("estado")
                );
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // UPDATE
    public void actualizarEstado(int id, int estado) {

        String sql = "UPDATE incidencias SET fk_estado=? WHERE id=?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, estado);
            ps.setInt(2, id);

            ps.executeUpdate();

            System.out.println("Estado actualizado");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // DELETE
    public void eliminar(int id) {

        String sql = "DELETE FROM incidencias WHERE id=?";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println("com.gestorincidencias.model.Incidencia eliminada");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}