document.addEventListener("DOMContentLoaded", () => {
  prepararFormularioIncidencia();
  prepararLogin();
  cargarIncidencias();
});

function prepararFormularioIncidencia() {
  const form = document.getElementById("formIncidencia");

  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const id = document.getElementById("id").value.trim();
    const fecha = document.getElementById("fecha").value;
    const descripcion = document.getElementById("descripcion").value.trim();
    const observaciones = document.getElementById("observaciones").value.trim();

    const nuevaIncidencia = {
      id,
      fecha,
      descripcion,
      observaciones,
      estado: "Pendiente"
    };

    console.log("Incidencia enviada:", nuevaIncidencia);

    let incidencias = JSON.parse(localStorage.getItem("incidencias")) || [];
    incidencias.push(nuevaIncidencia);
    localStorage.setItem("incidencias", JSON.stringify(incidencias));

    alert("Incidencia registrada correctamente");
    form.reset();
  });
}

function prepararLogin() {
  const formLogin = document.getElementById("formLogin");

  if (!formLogin) return;

  formLogin.addEventListener("submit", (e) => {
    e.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const password = document.getElementById("password").value.trim();

    console.log("Login:", { nombre, password });

    if (nombre === "" || password === "") {
      alert("Completa todos los campos");
      return;
    }

    window.location.href = "incidencias.html";
  });
}

function cargarIncidencias() {
  const lista = document.getElementById("listaIncidencias");

  if (!lista) return;

  const incidencias = JSON.parse(localStorage.getItem("incidencias")) || [];

  lista.innerHTML = "";

  if (incidencias.length === 0) {
    lista.innerHTML = `
      <div class="estado-row">
        <div class="estado-box">-</div>
        <div class="estado-box">-</div>
        <div class="estado-box">No hay incidencias</div>
      </div>
    `;
    return;
  }
  
  let contenido = "";


  incidencias.forEach((incidencia) => {
    contenido += `
      <div class="estado-row">
        <div class="estado-box">${incidencia.id}</div>
        <div class="estado-box">${incidencia.fecha}</div>
        <div class="estado-box">${incidencia.estado}</div>
      </div>
    `;
  });
  lista.innerHTML = contenido;
}