const formulario =
document.getElementById("incidenciaForm");

if(formulario){

    const dni =
    document.getElementById("dni");

    const fecha =
    document.getElementById("fecha");

    const descripcion =
    document.getElementById("descripcion");

    const mensajeError =
    document.getElementById("mensajeError");


    formulario.addEventListener(
    "submit",
    function(e){

        let correcto = true;

        mensajeError.textContent = "";

        dni.classList.remove("error");
        fecha.classList.remove("error");
        descripcion.classList.remove("error");
    


        // Campos obligatorios

        if(dni.value.trim()===""){

            dni.classList.add("error");
            correcto=false;

        }

        if(fecha.value.trim()===""){

            fecha.classList.add("error");
            correcto=false;

        }

        if(descripcion.value.trim()===""){

            descripcion.classList.add("error");
            correcto=false;

        }


        // descripción mínima

        if(
        descripcion.value.trim().length>0
        &&
        descripcion.value.trim().length<10
        ){

            descripcion.classList.add("error");

            mensajeError.textContent=
            "La descripción debe tener mínimo 10 caracteres";

            correcto=false;

        }


        if(!correcto){

            e.preventDefault();

            if(
            mensajeError.textContent===""
            ){

                mensajeError.textContent=
                "Completa los campos obligatorios";

            }

        }

    });


    dni.addEventListener(
    "input",
    limpiarErrores
    );

    fecha.addEventListener(
    "input",
    limpiarErrores
    );

    descripcion.addEventListener(
    "input",
    limpiarErrores
    );


    function limpiarErrores(){

        this.classList.remove(
        "error"
        );

        mensajeError.textContent="";

    }

}