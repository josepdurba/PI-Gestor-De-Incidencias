package com.gestorincidencias.dao;

import com.gestorincidencias.model.Incidencia;
import com.gestorincidencias.model.IncidenciaView;
import com.gestorincidencias.util.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class IncidenciaDAO {

    // =========================
    // CREATE (SIN FECHA)
    // =========================
    public void insertar(Incidencia i) {

        String sql = "INSERT INTO incidencias " +
                "(descripcion, observaciones, fk_usuario, fk_estado) " +
                "VALUES (?, ?, ?, ?)";

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, i.getDescripcion());
            ps.setString(2, i.getObservaciones());
            ps.setInt(3, i.getFkUsuario());
            ps.setInt(4, i.getFkEstado());

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // =========================
    // READ (LISTADO PARA JSP)
    // =========================
    public List<IncidenciaView> listar() {

        List<IncidenciaView> lista = new ArrayList<>();

        String sql =
                "SELECT u.DNI, i.fecha, e.estado " +
                        "FROM incidencias i " +
                        "JOIN usuarios u ON i.fk_usuario = u.id " +
                        "JOIN estados e ON i.fk_estado = e.id " +
                        "ORDER BY i.id DESC";

        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                Date fechaSql = rs.getDate("fecha");

                String fecha = (fechaSql != null)
                        ? fechaSql.toString()
                        : "Sin fecha";

                IncidenciaView view = new IncidenciaView(
                        rs.getString("DNI"),
                        fecha,
                        rs.getString("estado")
                );

                lista.add(view);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}