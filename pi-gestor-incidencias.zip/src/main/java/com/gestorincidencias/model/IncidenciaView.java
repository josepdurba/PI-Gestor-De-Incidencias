package com.gestorincidencias.model;

public class IncidenciaView {

    // 🧾 lo que necesita la vista
    private String dni;
    private String fecha;
    private String estado;

    public IncidenciaView() {}

    public IncidenciaView(String dni, String fecha, String estado) {
        this.dni = dni;
        this.fecha = fecha;
        this.estado = estado;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}