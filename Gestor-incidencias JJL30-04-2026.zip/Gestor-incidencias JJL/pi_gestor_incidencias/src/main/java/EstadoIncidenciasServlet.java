import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.*;
import java.sql.*;

@WebServlet("/estado-incidencias")
public class EstadoIncidenciasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        out.println(
            "<!DOCTYPE html>" +
            "<html lang='es'>" +
            "<head>" +
            "<meta charset='UTF-8'>" +
            "<title>Estado de incidencias</title>" +
            "</head>" +
            "<body>" +
            "<h1>Listado de incidencias</h1>"
        );

        String sql =
            "SELECT i.dni, i.fecha, e.estado " +
            "FROM incidencias i " +
            "JOIN estados e ON i.fk_estado = e.id";

        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
                
                out.println("<table border='1'>");
                out.println("<tr><th>DNI</th><th>Fecha</th><th>Estado</th></tr>");

                while (rs.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs.getString("dni") + "</td>");
                    out.println("<td>" + rs.getString("fecha") + "</td>");
                    out.println("<td>" + rs.getString("estado") + "</td>");
                    out.println("</tr>");
                }
                
                out.println("</table>");

        } catch (SQLException e) {
            out.println("Error: " + e.getMessage());
        }
        out.println(
            "<br>" +
            "<a href='incidencias.html'>Volver</a>" +
            "</body>" +
            "</html>"
        );
    }
}