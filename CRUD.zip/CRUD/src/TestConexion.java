import java.sql.Connection;
import java.sql.DriverManager;

public class TestConexion {
    public static void main(String[] args) {
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/pi_gestor_incidencias",
                    "root",
                    "1234"
            );
            System.out.println("Conectado correctamente a la base de datos");
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }
}