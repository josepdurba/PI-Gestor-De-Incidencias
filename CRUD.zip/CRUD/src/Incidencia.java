import java.sql.Date;

public class Incidencia {
    private int id;
    private int fk_estado;
    private int fk_usuario;
    private String descripcion;
    private String observaciones;
    private Date fecha;

    // Constructor simple
    public Incidencia() {}

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getFk_estado() { return fk_estado; }
    public void setFk_estado(int fk_estado) { this.fk_estado = fk_estado; }

    public int getFk_usuario() { return fk_usuario; }
    public void setFk_usuario(int fk_usuario) { this.fk_usuario = fk_usuario; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
}