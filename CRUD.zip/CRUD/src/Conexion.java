import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    public static Connection conectar() {
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/pi_gestor_incidencias",
                    "root",
                    "" // tu contraseña de MySQL, si tienes
            );
            return conn;
        } catch (Exception e) {
            System.out.println("Error al conectar: " + e);
            return null;
        }
    }
}