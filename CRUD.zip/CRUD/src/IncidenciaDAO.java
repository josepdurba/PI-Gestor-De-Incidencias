import java.sql.*;

public class IncidenciaDAO {

    public void crear(Incidencia i){
        try{
            Connection conn = Conexion.conectar();
            String sql = "INSERT INTO incidencias (fk_estado, fk_usuario, descripcion, observaciones, fecha) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, i.getFk_estado());
            ps.setInt(2, i.getFk_usuario());
            ps.setString(3, i.getDescripcion());
            ps.setString(4, i.getObservaciones());
            ps.setDate(5, i.getFecha());
            ps.executeUpdate();
            System.out.println("Incidencia creada");
        }catch(Exception e){
            System.out.println(e);
        }
    }

    public void leer(){
        try{
            Connection conn = Conexion.conectar();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM incidencias");
            while(rs.next()){
                System.out.println(rs.getInt("id") + " | " +
                        rs.getString("descripcion") + " | " +
                        rs.getString("observaciones"));
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }

    public void actualizar(int id, String nuevaDescripcion){
        try{
            Connection conn = Conexion.conectar();
            String sql = "UPDATE incidencias SET descripcion=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nuevaDescripcion);
            ps.setInt(2, id);
            ps.executeUpdate();
            System.out.println("Incidencia actualizada");
        }catch(Exception e){
            System.out.println(e);
        }
    }

    public void eliminar(int id){
        try{
            Connection conn = Conexion.conectar();
            String sql = "DELETE FROM incidencias WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Incidencia eliminada");
        }catch(Exception e){
            System.out.println(e);
        }
    }
}
